<div class="flex gap-2 justify-center">
    <!-- Tombol Edit -->
    <button
        wire:click.prevent="edit({{ $item->id }})"
        class="text-yellow-500 hover:text-yellow-700 transition"
        title="Edit Sub Kegiatan"
    >
        <i class="fas fa-edit fa-lg"></i>
    </button>

    <!-- Tombol Hapus -->
    <button
        wire:click.prevent="destroy({{ $item->id }})"
        onclick="confirm('Apakah Anda yakin ingin menghapus Sub Kegiatan ini?') || event.stopImmediatePropagation()"
        class="text-red-500 hover:text-red-700 transition"
        title="Hapus Sub Kegiatan"
    >
        <i class="fas fa-trash-alt fa-lg"></i>
    </button>
</div>
