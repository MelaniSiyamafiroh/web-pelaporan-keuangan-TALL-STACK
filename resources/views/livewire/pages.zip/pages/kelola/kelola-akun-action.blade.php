<div class="flex gap-2">
    {{-- Tombol Edit --}}
    <button
        wire:click="$emit('editUser', {{ $user->id }})"
        class="text-yellow-500 hover:text-yellow-700"
        title="Edit">
        <i class="fas fa-edit fa-lg"></i>
    </button>

    {{-- Tombol Hapus --}}
    <button
        wire:click="destroy({{ $user->id }})"
        onclick="confirm('Apakah Anda yakin ingin menghapus akun ini?') || event.stopImmediatePropagation()"
        class="text-red-600 hover:text-red-800"
        title="Hapus">
        <i class="fas fa-trash fa-lg"></i>
    </button>
</div>
