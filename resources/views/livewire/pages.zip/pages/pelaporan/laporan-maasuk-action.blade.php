<div>
    {{-- Modal --}}
    <div x-data="{ open: @entangle('isModalOpen') }" x-show="open"
         class="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-40"
         x-transition>
        <div @click.away="open = false" class="bg-white rounded-lg shadow-xl max-w-md w-full p-6">
            <h2 class="text-lg font-semibold mb-4 text-gray-700">
                Verifikasi / Revisi Laporan
            </h2>

            {{-- Catatan --}}
            <div class="mb-4">
                <label for="catatan" class="block text-sm font-medium text-gray-600 mb-1">
                    Catatan <span class="text-gray-400 italic">(Opsional untuk revisi)</span>
                </label>
                <textarea wire:model.defer="catatan" id="catatan" rows="3"
                          class="form-textarea w-full border-gray-300 rounded focus:ring focus:ring-blue-200"></textarea>
                @error('catatan') <span class="text-red-500 text-xs">{{ $message }}</span> @enderror
            </div>

            {{-- Action Buttons --}}
            <div class="flex justify-end gap-2 mt-4">
                <button wire:click="verifikasi"
                        class="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded shadow text-sm transition">
                    <i class="fas fa-check mr-1"></i> Verifikasi
                </button>

                <button wire:click="revisi"
                        class="bg-yellow-500 hover:bg-yellow-600 text-white px-4 py-2 rounded shadow text-sm transition">
                    <i class="fas fa-undo mr-1"></i> Revisi
                </button>

                <button @click="open = false"
                        class="bg-gray-300 hover:bg-gray-400 text-gray-700 px-4 py-2 rounded shadow text-sm transition">
                    Batal
                </button>
            </div>
        </div>
    </div>
</div>
