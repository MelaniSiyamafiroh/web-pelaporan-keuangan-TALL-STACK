<div class="max-w-7xl mx-auto p-6">

    {{-- Filter & Search horizontal --}}
    <div class="flex flex-col md:flex-row md:items-center mb-4 gap-2">
        {{-- Search --}}
        <div class="relative flex-1">
            <span class="absolute inset-y-0 left-0 flex items-center pl-3 text-gray-400">
                <i class="fas fa-search"></i>
            </span>
            <input type="text" wire:model.debounce.500ms="search" placeholder="Cari laporan..."
                   class="form-input w-full pl-10 pr-4 py-2 rounded border-gray-300 focus:ring focus:ring-blue-200 transition" />
        </div>

        {{-- Filter PPTK --}}
        <select wire:model.defer="pptkFilter" class="border rounded px-3 py-2 text-sm focus:ring focus:ring-blue-200">
            <option value="">Semua PPTK</option>
            <option value="2">IKP</option>
            <option value="3">TKI</option>
            <option value="4">Sekretariat</option>
        </select>

        {{-- Filter Tahun --}}
        <select wire:model.defer="tahunFilter" class="border rounded px-3 py-2 text-sm focus:ring focus:ring-blue-200">
            <option value="">Tahun</option>
            @for ($i = date('Y'); $i >= 2020; $i--)
                <option value="{{ $i }}">{{ $i }}</option>
            @endfor
        </select>

        {{-- Sort --}}
        <select wire:model.defer="sort" class="border rounded px-3 py-2 text-sm focus:ring focus:ring-blue-200">
            <option value="created_desc">Terbaru</option>
            <option value="created_asc">Terlama</option>
            <option value="nama_asc">Nama A-Z</option>
            <option value="nama_desc">Nama Z-A</option>
        </select>

        {{-- Tombol Terapkan --}}
        <button wire:click="applyFilter"
            class="bg-blue-600 hover:bg-blue-700 text-white font-semibold px-4 py-2 rounded shadow text-sm transition">
            Terapkan
        </button>
    </div>

    {{-- Table --}}
    <div class="overflow-x-auto bg-white rounded-lg shadow-lg">
        <table class="min-w-full divide-y divide-gray-200">
            <thead class="bg-blue-50">
                <tr class="text-gray-700 uppercase text-xs font-bold tracking-wider">
                    <th class="px-6 py-4">No</th>
                    <th class="px-6 py-4">PPTK</th>
                    <th class="px-6 py-4">Jenis</th>
                    <th class="px-6 py-4">Kegiatan</th>
                    <th class="px-6 py-4">Sub Kegiatan</th>
                    <th class="px-6 py-4">Rekening</th>
                    <th class="px-6 py-4">Periode</th>
                    <th class="px-6 py-4">Pagu</th>
                    <th class="px-6 py-4">Anggaran</th>
                    <th class="px-6 py-4">File</th>
                    <th class="px-6 py-4">Status</th>
                    <th class="px-6 py-4">Aksi</th>
                </tr>
            </thead>
            <tbody class="bg-white divide-y divide-gray-100">
                @foreach ($laporanMasuk as $index => $data)
                    <tr class="hover:bg-gray-50">
                        <td class="px-6 py-4">{{ $loop->iteration + ($laporanMasuk->currentPage() - 1) * $laporanMasuk->perPage() }}</td>
                        <td class="px-6 py-4 uppercase">
                            @php
                                $pptkMapping = [2 => 'IKP', 3 => 'TKI', 4 => 'Sekretariat'];
                            @endphp
                            {{ $pptkMapping[$data->pptk_id] ?? '-' }}
                        </td>
                        <td class="px-6 py-4">{{ $data->jenis_belanja }}</td>
                        <td class="px-6 py-4">{{ $data->kegiatan->nama_kegiatan ?? '-' }}</td>
                        <td class="px-6 py-4">{{ $data->subkegiatan->nama_subkegiatan ?? '-' }}</td>
                        <td class="px-6 py-4">{{ $data->rekening_kegiatan }}</td>
                        <td class="px-6 py-4">{{ $data->periode }}</td>
                        <td class="px-6 py-4">Rp{{ number_format($data->nominal_pagu, 0, ',', '.') }}</td>
                        <td class="px-6 py-4">Rp{{ number_format($data->nominal, 0, ',', '.') }}</td>
                        <td class="px-6 py-4">
                            @if ($data->file_path)
                                <a href="{{ asset('storage/' . $data->file_path) }}" target="_blank"
                                   class="text-blue-600 hover:text-blue-800 flex justify-center">
                                    <i class="fas fa-file-pdf fa-lg text-red-500"></i>
                                </a>
                            @else
                                <span class="text-gray-400 italic">Tidak ada</span>
                            @endif
                        </td>
                        <td class="px-6 py-4">{{ $data->status }}</td>
                        <td class="px-6 py-4 flex gap-2">
                            <button wire:click="verifikasi({{ $data->id }})"
                                    class="text-green-600 hover:text-green-800">
                                <i class="fas fa-check fa-lg"></i>
                            </button>
                            <button wire:click="setSelectedId({{ $data->id }})"
                                    x-data
                                    x-on:click="$dispatch('open-modal', { id: {{ $data->id }} })"
                                    class="text-yellow-500 hover:text-yellow-700">
                                <i class="fas fa-edit fa-lg"></i>
                            </button>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>

    <div class="mt-4">
        {{ $laporanMasuk->links() }}
    </div>

    {{-- Modal revisi (opsional, bisa ganti pakai component/modal lain) --}}
    <div x-data="{ open: false }"
         x-on:open-modal.window="if ($event.detail.id) open=true"
         x-show="open"
         class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
        <div class="bg-white rounded p-4 w-full max-w-md">
            <h2 class="text-lg font-semibold mb-2">Revisi Laporan</h2>
            <textarea wire:model.defer="catatan" rows="3"
                      class="w-full border rounded p-2 mb-3" placeholder="Tulis catatan revisi..."></textarea>
            <div class="flex justify-end gap-2">
                <button @click="open=false" class="px-3 py-2 bg-gray-300 rounded">Batal</button>
                <button wire:click="revisi(selectedId)" class="px-3 py-2 bg-yellow-500 text-white rounded">Kirim Revisi</button>
            </div>
        </div>
    </div>
</div>

