<div class="max-w-7xl mx-auto p-6">

    <!-- Heading dan Tombol -->
    <div class="flex flex-col md:flex-row md:items-center justify-between mb-6 gap-4">
        <h2 class="text-xl font-semibold text-gray-700">Daftar Pelaporan</h2>

        <div class="flex flex-col md:flex-row md:items-center gap-2 w-full md:w-auto">
            <input type="text" wire:model.debounce.500ms="search" placeholder="Cari..."
                class="form-input w-full md:w-64 px-4 py-2 rounded-lg border-gray-300 focus:ring focus:ring-blue-200 transition" />

            <button wire:click="$set('showModal', true)"
                class="bg-blue-600 hover:bg-blue-700 text-white font-semibold px-4 py-2 rounded-lg shadow-md transition">
                <i class="fas fa-plus mr-2"></i>Tambah Pelaporan
            </button>
        </div>
    </div>

    <!-- Filter Horizontal -->
    <div class="flex flex-col md:flex-row md:items-center gap-2 mb-4">
        <div class="flex-1">
            <select wire:model="status" class="form-select w-full">
                <option value="">-- Semua Status --</option>
                <option value="draft">Draft</option>
                <option value="diajukan">Diajukan</option>
                <option value="disetujui">Disetujui</option>
                <option value="ditolak">Ditolak</option>
            </select>
        </div>

        <div class="flex-1">
            <input type="number" wire:model="tahun" placeholder="Tahun"
                class="form-input w-full" />
        </div>

        <div class="flex-1">
            <select wire:model="sort" class="form-select w-full">
                <option value="created_desc">Terbaru</option>
                <option value="created_asc">Terlama</option>
            </select>
        </div>

        <div>
            <button wire:click="$refresh"
                class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg shadow-md transition">
                <i class="fas fa-check mr-1"></i> Terapkan
            </button>
        </div>
    </div>

    <!-- Tabel -->
    <div class="overflow-x-auto bg-white rounded-lg shadow">
        <table class="min-w-full divide-y divide-gray-200">
            <thead class="bg-blue-50 text-gray-700 uppercase text-xs font-bold">
                <tr>
                    <th class="px-6 py-4 text-left">No</th>
                    <th class="px-6 py-4 text-left">Jenis Belanja</th>
                    <th class="px-6 py-4 text-left">Rekening</th>
                    <th class="px-6 py-4 text-left">Periode</th>
                    <th class="px-6 py-4 text-left">Status</th>
                    <th class="px-6 py-4 text-left">Catatan</th>
                    <th class="px-6 py-4 text-left">Aksi</th>
                </tr>
            </thead>
            <tbody class="bg-white divide-y divide-gray-100">
                @forelse ($laporan as $index => $item)
                <tr class="hover:bg-gray-50 transition">
                    <td class="px-6 py-4">{{ $index + 1 + ($laporan->currentPage() - 1) * $laporan->perPage() }}</td>
                    <td class="px-6 py-4">{{ $item->jenis_belanja }}</td>
                    <td class="px-6 py-4">{{ $item->rekening_kegiatan }}</td>
                    <td class="px-6 py-4">{{ \Carbon\Carbon::parse($item->periode)->translatedFormat('F Y') }}</td>
                    <td class="px-6 py-4">
                        <span class="px-2 py-1 rounded-full text-xs font-semibold
                            @if($item->status === 'draft') bg-gray-200 text-gray-700
                            @elseif($item->status === 'diajukan') bg-yellow-200 text-yellow-800
                            @elseif($item->status === 'disetujui') bg-green-200 text-green-800
                            @elseif($item->status === 'ditolak') bg-red-200 text-red-800
                            @endif">
                            {{ ucfirst($item->status) }}
                        </span>
                    </td>
                    <td class="px-6 py-4">{{ $item->catatan }}</td>
                    <td class="px-6 py-4">
                        <!-- Tombol aksi, bisa diisi edit/hapus -->
                        <button class="text-blue-600 hover:underline">Detail</button>
                    </td>
                </tr>
                @empty
                <tr>
                    <td colspan="7" class="text-center text-gray-500 py-6">Data pelaporan tidak ditemukan.</td>
                </tr>
                @endforelse
            </tbody>
        </table>
    </div>

    <!-- Pagination -->
    <div class="mt-4">
        {{ $laporan->links() }}
    </div>

    <!-- Modal Form -->
    @include('livewire.pages.pelaporan.modal-form')

</div>
