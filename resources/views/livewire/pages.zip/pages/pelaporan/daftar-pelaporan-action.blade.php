<div
    x-data="{ open: @entangle('modalOpen') }"
    x-show="open"
    class="fixed inset-0 flex items-center justify-center bg-black/50 z-50"
    style="display: none;"
>
    <div class="bg-white dark:bg-gray-800 rounded-lg shadow-lg max-w-3xl w-full mx-4 p-6 relative"
         @click.away="open = false">

        <h2 class="text-lg font-semibold mb-4">
            {{ $editingId ? 'Edit Pelaporan' : 'Tambah Pelaporan' }}
        </h2>

        <form wire:submit.prevent="{{ $editingId ? 'update' : 'store' }}">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">

                <!-- PPTK -->
                <div>
                    <label class="block text-sm mb-1">PPTK</label>
                    <select wire:model.defer="form.pptk_id"
                            class="w-full border-gray-300 rounded-lg">
                        <option value="">-- Pilih PPTK --</option>
                        @foreach($pptks as $pptk)
                            <option value="{{ $pptk->id }}">{{ $pptk->role }}</option>
                        @endforeach
                    </select>
                    @error('form.pptk_id') <span class="text-red-500 text-xs">{{ $message }}</span> @enderror
                </div>

                <!-- Jenis Belanja -->
                <div>
                    <label class="block text-sm mb-1">Jenis Belanja</label>
                    <input type="text" wire:model.defer="form.jenis_belanja"
                           class="w-full border-gray-300 rounded-lg">
                    @error('form.jenis_belanja') <span class="text-red-500 text-xs">{{ $message }}</span> @enderror
                </div>

                <!-- Kegiatan -->
                <div>
                    <label class="block text-sm mb-1">Kegiatan</label>
                    <select wire:model.defer="form.kegiatan_id"
                            class="w-full border-gray-300 rounded-lg">
                        <option value="">-- Pilih Kegiatan --</option>
                        @foreach($kegiatans as $kegiatan)
                            <option value="{{ $kegiatan->id }}">{{ $kegiatan->nama_kegiatan }}</option>
                        @endforeach
                    </select>
                    @error('form.kegiatan_id') <span class="text-red-500 text-xs">{{ $message }}</span> @enderror
                </div>

                <!-- Sub Kegiatan -->
                <div>
                    <label class="block text-sm mb-1">Sub Kegiatan</label>
                    <select wire:model.defer="form.subkegiatan_id"
                            class="w-full border-gray-300 rounded-lg">
                        <option value="">-- Pilih Sub Kegiatan --</option>
                        @foreach($subkegiatans as $sub)
                            <option value="{{ $sub->id }}">{{ $sub->nama_subkegiatan }}</option>
                        @endforeach
                    </select>
                    @error('form.subkegiatan_id') <span class="text-red-500 text-xs">{{ $message }}</span> @enderror
                </div>

                <!-- Rekening Kegiatan -->
                <div>
                    <label class="block text-sm mb-1">Rekening Kegiatan</label>
                    <input type="text" wire:model.defer="form.rekening_kegiatan"
                           class="w-full border-gray-300 rounded-lg">
                    @error('form.rekening_kegiatan') <span class="text-red-500 text-xs">{{ $message }}</span> @enderror
                </div>

                <!-- Periode -->
                <div>
                    <label class="block text-sm mb-1">Periode</label>
                    <input type="month" wire:model.defer="form.periode"
                           class="w-full border-gray-300 rounded-lg">
                    @error('form.periode') <span class="text-red-500 text-xs">{{ $message }}</span> @enderror
                </div>

                <!-- Nominal Pagu -->
                <div>
                    <label class="block text-sm mb-1">Nominal Pagu</label>
                    <input type="number" wire:model.defer="form.nominal_pagu"
                           class="w-full border-gray-300 rounded-lg">
                    @error('form.nominal_pagu') <span class="text-red-500 text-xs">{{ $message }}</span> @enderror
                </div>

                <!-- Anggaran Sekarang -->
                <div>
                    <label class="block text-sm mb-1">Anggaran Sekarang</label>
                    <input type="number" wire:model.defer="form.nominal"
                           class="w-full border-gray-300 rounded-lg">
                    @error('form.nominal') <span class="text-red-500 text-xs">{{ $message }}</span> @enderror
                </div>

                <!-- File Upload -->
                <div class="md:col-span-2">
                    <label class="block text-sm mb-1">Upload File (PDF, max 2MB)</label>
                    <input type="file" wire:model="fileUpload"
                           class="w-full border-gray-300 rounded-lg">
                    @error('fileUpload') <span class="text-red-500 text-xs">{{ $message }}</span> @enderror

                    @if ($fileUpload)
                        <span class="text-xs text-green-600">File terpilih: {{ $fileUpload->getClientOriginalName() }}</span>
                    @elseif($editingId && $form['file_path'])
                        <a href="{{ asset('storage/'.$form['file_path']) }}" target="_blank"
                           class="text-blue-500 text-xs underline mt-1 inline-block">Lihat file lama</a>
                    @endif
                </div>

                <!-- Catatan -->
                <div class="md:col-span-2">
                    <label class="block text-sm mb-1">Catatan</label>
                    <textarea wire:model.defer="form.catatan"
                              class="w-full border-gray-300 rounded-lg"></textarea>
                    @error('form.catatan') <span class="text-red-500 text-xs">{{ $message }}</span> @enderror
                </div>

            </div>

            <div class="flex justify-end mt-4 gap-2">
                <button type="button" @click="open = false"
                        class="bg-gray-200 hover:bg-gray-300 px-4 py-2 rounded-lg">
                    Batal
                </button>
                <button type="submit"
                        class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg shadow">
                    Simpan
                </button>
            </div>
        </form>
    </div>
</div>
