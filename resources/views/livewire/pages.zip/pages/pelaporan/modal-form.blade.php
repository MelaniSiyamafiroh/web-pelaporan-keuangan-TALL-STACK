<div x-data="{ showModal: @entangle('showModal') }" x-cloak>
    <!-- Overlay -->
    <div x-show="showModal" class="fixed inset-0 bg-black bg-opacity-50 z-40"></div>

    <!-- Modal -->
    <div x-show="showModal" class="fixed inset-0 z-50 flex items-center justify-center overflow-y-auto px-4">
        <div class="bg-white rounded-lg shadow-lg w-full max-w-xl p-6" @click.away="showModal = false">
            <h2 class="text-lg font-semibold text-gray-700 mb-4">Form Pelaporan</h2>

            <form wire:submit.prevent="submit">
                <!-- Jenis Belanja -->
                <div class="mb-4">
                    <label class="block text-sm font-medium text-gray-700">Jenis Belanja</label>
                    <input type="text" wire:model="jenis_belanja" class="form-input w-full">
                    @error('jenis_belanja') <span class="text-red-500 text-sm">{{ $message }}</span> @enderror
                </div>

                <!-- Rekening -->
                <div class="mb-4">
                    <label class="block text-sm font-medium text-gray-700">Rekening</label>
                    <input type="text" wire:model="rekening_kegiatan" class="form-input w-full">
                    @error('rekening_kegiatan') <span class="text-red-500 text-sm">{{ $message }}</span> @enderror
                </div>

                <!-- Periode -->
                <div class="mb-4">
                    <label class="block text-sm font-medium text-gray-700">Periode</label>
                    <input type="month" wire:model="periode" class="form-input w-full">
                    @error('periode') <span class="text-red-500 text-sm">{{ $message }}</span> @enderror
                </div>

                <!-- Catatan -->
                <div class="mb-4">
                    <label class="block text-sm font-medium text-gray-700">Catatan</label>
                    <textarea wire:model="catatan" class="form-textarea w-full"></textarea>
                    @error('catatan') <span class="text-red-500 text-sm">{{ $message }}</span> @enderror
                </div>

                <!-- Tombol Aksi -->
                <div class="flex justify-end mt-6">
                    <button type="button" @click="showModal = false" class="bg-gray-300 px-4 py-2 rounded mr-2">Batal</button>
                    <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded">Simpan</button>
                </div>
            </form>
        </div>
    </div>
</div>
