<?php

namespace App\Livewire\Pages\Pelaporan;

use Livewire\Component;
use Livewire\WithPagination;
use App\Models\Pelaporan;
use Illuminate\Support\Facades\Auth;

class DaftarPelaporanTabel extends Component
{
    use WithPagination;

    public $search = '';
    public $filterPptk = '';
    public $filterStatus = '';
    public $filterTahun = '';
    public $sort = 'created_desc';

    public $modalOpen = false;
    public $editingId = null;

    protected $queryString = [
        'search' => ['except' => ''],
        'filterPptk' => ['except' => ''],
        'filterStatus' => ['except' => ''],
        'filterTahun' => ['except' => ''],
        'sort' => ['except' => 'created_desc'],
    ];

    protected $listeners = ['refreshTable' => '$refresh'];

    public function updatingSearch()
    {
        $this->resetPage();
    }

    public function updatingFilterPptk()
    {
        $this->resetPage();
    }

    public function updatingFilterStatus()
    {
        $this->resetPage();
    }

    public function updatingFilterTahun()
    {
        $this->resetPage();
    }

    public function updatingSort()
    {
        $this->resetPage();
    }

    public function openModal()
    {
        $this->editingId = null;
        $this->modalOpen = true;
    }

    public function edit($id)
    {
        $this->editingId = $id;
        $this->modalOpen = true;
    }

    public function closeModal()
    {
        $this->modalOpen = false;
    }

    public function confirmDelete($id)
    {
        Pelaporan::findOrFail($id)->delete();
        session()->flash('message', 'Pelaporan berhasil dihapus!');
        $this->emitSelf('refreshTable');
    }

    public function render()
    {
        $query = Pelaporan::with(['pptk', 'kegiatan', 'subkegiatan']);
        $user = Auth::user();

        // Filter
        if ($this->filterPptk) {
            $query->where('pptk_id', $this->filterPptk);
        }

        if ($this->filterStatus) {
            $query->where('status', $this->filterStatus);
        }

        if ($this->filterTahun) {
            $query->whereYear('periode', $this->filterTahun);
        }

        // Search
        if ($this->search) {
            $searchTerm = '%' . $this->search . '%';
            $query->where(function ($q) use ($searchTerm) {
                $q->whereHas('pptk', function ($q2) use ($searchTerm) {
                    $q2->where('role', 'like', $searchTerm);
                })
                  ->orWhere('jenis_belanja', 'like', $searchTerm)
                  ->orWhereHas('kegiatan', function ($q2) use ($searchTerm) {
                      $q2->where('nama_kegiatan', 'like', $searchTerm);
                  })
                  ->orWhereHas('subkegiatan', function ($q2) use ($searchTerm) {
                      $q2->where('nama_subkegiatan', 'like', $searchTerm);
                  })
                  ->orWhere('rekening_kegiatan', 'like', $searchTerm)
                  ->orWhere('periode', 'like', $searchTerm)
                  ->orWhere('status', 'like', $searchTerm)
                  ->orWhere('catatan', 'like', $searchTerm);
            });
        }

        // Sort
        switch ($this->sort) {
            case 'created_asc':
                $query->orderBy('created_at', 'asc');
                break;
            case 'nama_asc':
                $query->orderBy(function ($q) {
                    $q->from('users')
                        ->select('role')
                        ->whereColumn('users.id', 'pelaporans.pptk_id');
                }, 'asc');
                break;
            case 'nama_desc':
                $query->orderBy(function ($q) {
                    $q->from('users')
                        ->select('role')
                        ->whereColumn('users.id', 'pelaporans.pptk_id');
                }, 'desc');
                break;
            default:
                $query->orderBy('created_at', 'desc');
                break;
        }

        // Role filter: jika user bukan admin/bendahara/verifikator/kepala_dinas
        if (!in_array($user->role, ['admin', 'bendahara', 'verifikator', 'kepala_dinas'])) {
            $query->whereHas('pptk', function ($q) use ($user) {
                $q->where('role', $user->role);
            });
        }

        $laporan = $query->paginate(10);

        return view('livewire.pages.pelaporan.daftar-pelaporan-tabel', [
            'laporan' => $laporan,
            'modalOpen' => $this->modalOpen,
            'editingId' => $this->editingId,
        ]);
    }
}
