<?php

namespace App\Livewire\Pages\Pelaporan;

use Livewire\Component;
use App\Models\Pelaporan;
use App\Models\VerifikasiLaporan;
use Illuminate\Support\Facades\Auth;

class LaporanMasukPage extends Component
{
    public $catatan = '';
    public $selectedId = null;

    public function verifikasi($id)
    {
        $user = Auth::user();
        $laporan = Pelaporan::findOrFail($id);

        VerifikasiLaporan::create([
            'dpa_skpd_id' => $laporan->id,
            'verifikator_id' => $user->id,
            'tanggal_verifikasi' => now(),
            'catatan' => '-', // default catatan
            'status' => 'Disetujui',
        ]);

        if ($user->role === 'verifikator') {
            $laporan->status = 'Disetujui Verifikator';
        } elseif ($user->role === 'bendahara') {
            $laporan->status = 'Disetujui Bendahara';
        } elseif ($user->role === 'kepala_dinas') {
            $laporan->status = 'Disetujui Kepala Dinas';
        }

        $laporan->save();

        session()->flash('success', 'Laporan berhasil diverifikasi.');
    }

    public function revisi($id)
    {
        $this->validate([
            'catatan' => 'required|string',
        ]);

        $user = Auth::user();
        $laporan = Pelaporan::findOrFail($id);

        VerifikasiLaporan::create([
            'dpa_skpd_id' => $laporan->id,
            'verifikator_id' => $user->id,
            'tanggal_verifikasi' => now(),
            'catatan' => $this->catatan,
            'status' => 'Revisi',
        ]);

        $laporan->status = 'Perlu Revisi';
        $laporan->catatan = $this->catatan;
        $laporan->save();

        $this->reset('catatan', 'selectedId');
        session()->flash('success', 'Laporan dikembalikan untuk revisi.');
    }

    public function setSelectedId($id)
    {
        $this->selectedId = $id;
    }

    public function render()
    {
        $laporanMasuk = Pelaporan::latest()->paginate(10);

        return view('livewire.pages.pelaporan.laporan-masuk-page', [
            'laporanMasuk' => $laporanMasuk
        ]);
    }
}
