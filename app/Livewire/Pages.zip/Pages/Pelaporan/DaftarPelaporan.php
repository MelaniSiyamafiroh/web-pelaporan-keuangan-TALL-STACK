<?php

namespace App\Livewire\Pages\Pelaporan;

use Livewire\Component;
use Livewire\WithPagination;
use App\Models\Pelaporan;
use Illuminate\Support\Facades\Auth;

class DaftarPelaporan extends Component
{
    use WithPagination;

    // Query filter
    public $search = '';
    public $status = '';
    public $tahun = '';
    public $sort = 'created_desc';
    public $perPage = 10;

    // Modal form properties
    public $showModal = false;
    public $jenis_belanja;
    public $rekening_kegiatan;
    public $periode;
    public $catatan;

    protected $queryString = [
        'search' => ['except' => ''],
        'status' => ['except' => ''],
        'tahun'  => ['except' => ''],
        'sort'   => ['except' => 'created_desc'],
        'page'   => ['except' => 1],
    ];

    protected $rules = [
        'jenis_belanja'      => 'required|string|max:255',
        'rekening_kegiatan'  => 'required|string|max:255',
        'periode'            => 'required|date',
        'catatan'            => 'nullable|string|max:1000',
    ];

    public function updatingSearch() { $this->resetPage(); }
    public function updatingStatus() { $this->resetPage(); }
    public function updatingTahun()  { $this->resetPage(); }

    public function render()
    {
        $user = Auth::user();

        $query = Pelaporan::with(['pptk.roles', 'kegiatan', 'subkegiatan']);

        // Filter by status
        if ($this->status) {
            $query->where('status', $this->status);
        }

        // Filter by year
        if ($this->tahun) {
            $query->whereYear('periode', $this->tahun);
        }

        // Filter by user role (non-pptk)
        if (!in_array($user->getRoleNames()->first(), ['pptk_tki', 'pptk_ikp', 'pptk_sekretaris'])) {
            $query->whereHas('pptk.roles', function ($q) use ($user) {
                $q->where('name', $user->getRoleNames()->first());
            });
        }

        // Search
        if ($this->search) {
            $query->where(function ($q) {
                $q->whereHas('pptk.roles', fn($q2) => $q2->where('name', 'like', '%'.$this->search.'%'))
                  ->orWhere('jenis_belanja', 'like', '%'.$this->search.'%')
                  ->orWhereHas('kegiatan', fn($q2) => $q2->where('nama_kegiatan', 'like', '%'.$this->search.'%'))
                  ->orWhereHas('subkegiatan', fn($q2) => $q2->where('nama_subkegiatan', 'like', '%'.$this->search.'%'))
                  ->orWhere('rekening_kegiatan', 'like', '%'.$this->search.'%')
                  ->orWhere('periode', 'like', '%'.$this->search.'%')
                  ->orWhere('status', 'like', '%'.$this->search.'%')
                  ->orWhere('catatan', 'like', '%'.$this->search.'%');
            });
        }

        // Sort
        switch ($this->sort) {
            case 'created_asc':
                $query->orderBy('created_at', 'asc');
                break;
            default:
                $query->orderBy('created_at', 'desc');
                break;
        }

        $laporan = $query->paginate($this->perPage);

        return view('livewire.pages.pelaporan.daftar-pelaporan', compact('laporan'));
    }

    public function submit()
    {
        $this->validate();

        Pelaporan::create([
            'jenis_belanja'      => $this->jenis_belanja,
            'rekening_kegiatan'  => $this->rekening_kegiatan,
            'periode'            => $this->periode,
            'catatan'            => $this->catatan,
            'user_id'            => auth()->id(), // sesuaikan jika pakai relasi pptk
            'status'             => 'draft',
        ]);

        $this->resetForm();

        session()->flash('success', 'Pelaporan berhasil ditambahkan.');
    }

    public function resetForm()
    {
        $this->reset([
            'showModal',
            'jenis_belanja',
            'rekening_kegiatan',
            'periode',
            'catatan',
        ]);
    }
}
