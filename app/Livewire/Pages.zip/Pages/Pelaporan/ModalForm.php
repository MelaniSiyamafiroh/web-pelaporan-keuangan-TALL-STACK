<?php

namespace App\Livewire\Pages\Pelaporan;

use Livewire\Component;

class ModalForm extends Component
{
    public function render()
    {
        return view('livewire.pages.pelaporan.modal-form');
    }
}
