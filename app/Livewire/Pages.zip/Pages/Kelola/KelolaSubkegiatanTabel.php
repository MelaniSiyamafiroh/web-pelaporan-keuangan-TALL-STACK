<?php

namespace App\Livewire\Pages\Kelola;

use Rappasoft\LaravelLivewireTables\DataTableComponent;
use Rappasoft\LaravelLivewireTables\Views\Column;
use App\Models\Subkegiatan;

class KelolaSubkegiatanTabel extends DataTableComponent
{
    protected $model = Subkegiatan::class;

    public function configure(): void
    {
        $this->setPrimaryKey('id');
    }

    public function columns(): array
    {
        return [
            Column::make("Id", "id")
                ->sortable(),
            Column::make("Id kegiatan", "id_kegiatan")
                ->sortable(),
            Column::make("Nama subkegiatan", "nama_subkegiatan")
                ->sortable(),
            Column::make("Tahun anggaran", "tahun_anggaran")
                ->sortable(),
            Column::make("Rekening", "rekening")
                ->sortable(),
            Column::make("Jumlah pagu", "jumlah_pagu")
                ->sortable(),
            Column::make("Created at", "created_at")
                ->sortable(),
            Column::make("Updated at", "updated_at")
                ->sortable(),
        ];
    }
}
