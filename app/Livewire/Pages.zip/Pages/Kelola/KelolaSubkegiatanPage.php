<?php

namespace App\Livewire\Pages\Kelola;

use App\Models\SubKegiatan;
use App\Models\Kegiatan;
use Livewire\Component;
use Livewire\WithPagination;

class KelolaSubkegiatanPage extends Component
{
    use WithPagination;

    public $search = '';
    public $sort = 'created_desc';
    public $id_kegiatan = '';
    public $tahun_anggaran = '';

    public $nama_subkegiatan;
    public $edit_id = null;

    protected $rules = [
        'nama_subkegiatan' => 'required|string|max:255',
        'id_kegiatan' => 'required|exists:kegiatans,id',
        'tahun_anggaran' => 'required|integer',
    ];

    protected $paginationTheme = 'tailwind';

    public function render()
    {
        $query = SubKegiatan::with('kegiatan');

        if ($this->id_kegiatan) {
            $query->where('id_kegiatan', $this->id_kegiatan);
        }

        if ($this->tahun_anggaran) {
            $query->where('tahun_anggaran', $this->tahun_anggaran);
        }

        if ($this->search) {
            $query->where('nama_subkegiatan', 'like', '%' . $this->search . '%');
        }

        switch ($this->sort) {
            case 'created_asc':
                $query->orderBy('created_at', 'asc');
                break;
            case 'nama_asc':
                $query->orderBy('nama_subkegiatan', 'asc');
                break;
            case 'nama_desc':
                $query->orderBy('nama_subkegiatan', 'desc');
                break;
            default:
                $query->orderBy('created_at', 'desc');
                break;
        }

        $subkegiatan = $query->paginate(10);
        $kegiatan = Kegiatan::all();

        return view('livewire.pages.kelola.kelola-subkegiatan-page', [
            'subkegiatan' => $subkegiatan,
            'kegiatan' => $kegiatan,
        ]);
    }

    public function store()
    {
        $validated = $this->validate();

        try {
            SubKegiatan::create($validated);
            session()->flash('success', 'Sub Kegiatan berhasil ditambahkan.');
            $this->resetForm();
        } catch (\Exception $e) {
            session()->flash('error', 'Gagal menambahkan Sub Kegiatan: ' . $e->getMessage());
        }
    }

    public function edit($id)
    {
        $data = SubKegiatan::findOrFail($id);
        $this->edit_id = $data->id;
        $this->nama_subkegiatan = $data->nama_subkegiatan;
        $this->id_kegiatan = $data->id_kegiatan;
        $this->tahun_anggaran = $data->tahun_anggaran;
    }

    public function update()
    {
        $validated = $this->validate();

        try {
            $data = SubKegiatan::findOrFail($this->edit_id);
            $data->update($validated);
            session()->flash('success', 'Sub Kegiatan berhasil diperbarui.');
            $this->resetForm();
        } catch (\Exception $e) {
            session()->flash('error', 'Gagal memperbarui Sub Kegiatan: ' . $e->getMessage());
        }
    }

    public function destroy($id)
    {
        try {
            SubKegiatan::findOrFail($id)->delete();
            session()->flash('success', 'Sub Kegiatan berhasil dihapus.');
        } catch (\Exception $e) {
            session()->flash('error', 'Gagal menghapus Sub Kegiatan: ' . $e->getMessage());
        }
    }

    public function resetForm()
    {
        $this->edit_id = null;
        $this->nama_subkegiatan = '';
        $this->id_kegiatan = '';
        $this->tahun_anggaran = '';
    }

    public function updatingSearch()
    {
        $this->resetPage();
    }

    public function updatingIdKegiatan()
    {
        $this->resetPage();
    }

    public function updatingTahunAnggaran()
    {
        $this->resetPage();
    }

    public function updatingSort()
    {
        $this->resetPage();
    }
}
